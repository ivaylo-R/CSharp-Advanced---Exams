﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Bakery.Models.BakedFoods
{
    public class Bread : Food
    {
        private const int initialBreadPortion = 200;
        public Bread(string name, int portion, decimal price) : base(name, portion, price)
        {
            this.Portion = initialBreadPortion;
        }
    }
}
